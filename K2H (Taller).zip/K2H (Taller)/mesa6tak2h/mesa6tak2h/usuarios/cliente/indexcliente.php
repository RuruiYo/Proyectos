<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css\estiloindexcliente.css"> </head>
    <title>K2H </title>
   
</head>
<body>
    <div>
    <header>
        <img src="imagenes/unnamed.png" alt="Botón" width="110" height="70"> 
        <a href="../../iniciodesesion.php"><img src="imagenes/pngwing.com (1).png" width="50" height="50"></a>
       <a href="html\carrito.php"><img src="imagenes/carro-removebg-preview.png" alt="boton" class="cart" width="70" height="70"></a>
       
    </header>
    </div>

    <div class="main-content">
        <div class="category-card">
            <img src="imagenes/Captura de pantalla 2024-09-11 153100.png" width="100%" height="auto">
        </div>
    </div>
    <div class="category-card">
        <img src="imagenes\cososevi.png" width="100%" height="auto">
    </div>
    <div class="card">
        <img src="imagenes/257-SW-La-importancia-del-Mantenimiento-Preventivo-02.png">
        <div class="text"> <a href="html/preventivo.php">PREVENTIVO</a></div>
    </div>
    <div class="card">
        <img src="imagenes/checklistfacil-mantenimiento-correctivo.jpg">
        <div class="text"> <a href="html\correctivo.php">CORRECTIVO</a></div>
    </div>
    <div class="card">
        <img src="imagenes/los-descuentos-02.jpg">
        <div class="text"> <a href="html\promociones.php">PROMOCIONES</a></div>
    </div>
    <div>
        <img src="imagenes\Captura de pantalla 2024-09-11 210049.png" width="100%" height="auto">
    </div>


    <div class="scrolling-buttons-container">
        <span id="scrolling-button-left"><img src="imagenes/dos.png" width="50" height="50"></span>
        <span id="scrolling-button-right"><img src="imagenes/pngwing.com.png" width="50" height="50"></span>
      </div>

  
      <div class="scrolling-container">
        <div class="scrolling-card">
            <h2></h2>
        </div>
        <div class="scrolling-card">
            <h2></h2>
        </div>
        <div class="scrolling-card">
            <h2></h2>
        </div>
        <div class="scrolling-card">
            <h2></h2>
           
        </div>
        <div class="scrolling-card">
            <h2></h2>
        </div>
        <div class="scrolling-card">
            <img src="imagenes/KI.jpg" width="200" height="200" alt="">
            <h2>Nombre del producto</h2>
            <h3>$29.99 &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; <button class="circle-btn">+</button></h3>
            
        </div>
        <div class="scrolling-card"><h2></h2></div>
        <div class="scrolling-card"><h2></h2></div>
        <div class="scrolling-card"><h2></h2></div>
        <div class="scrolling-card"><h2></h2></div>
        <div class="scrolling-card"><h2></h2></div>
        <div class="scrolling-card"><h2></h2></div>
        <div class="scrolling-card"><h2></h2></div>
        <div class="scrolling-card"><h2></h2></div>
        <div class="scrolling-card"><h2></h2></div>
        <div class="scrolling-card"><h2></h2></div>
        <div class="scrolling-card"><h2></h2></div>
        <div class="scrolling-card"><h2></h2></div>
      </div> 
</div>

<br><br>

<script src= "java\indexjava.js"></script>

</body>

<footer>
    <p class="footerrr">Josué Kadosh #19 &nbsp;&nbsp;&nbsp; José Steven #15
        &nbsp;&nbsp;&nbsp;Diego Josué #7 &nbsp;&nbsp;&nbsp; Rodrigo Lemus #6     
        &nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Copyright ©2024 K2H</p>

    <!-- Agrupamos las imágenes de redes sociales en un div -->
    <div class="social-icons">
        <a href="https://www.instagram.com" target="_blank">
            <img src="../../media/image-removebg-preview (2).png" alt="instagram" class="social-icon">
        </a>
        
        <!-- Enlace a Twitter/X -->
        <a href="https://www.twitter.com" target="_blank">
            <img src="../../media/image-removebg-preview (3).png" alt="X(twitter)" class="social-iconn">
        </a>

        <!-- Enlace a Facebook -->
        <a href="https://www.facebook.com" target="_blank">
            <img src="../../media/image-removebg-preview (4).png" alt="Facebook" class="social-icon">
        </a>
    </div>
</footer>
</html>