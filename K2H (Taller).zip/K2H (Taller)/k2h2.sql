-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 27-02-2025 a las 18:36:13
-- Versión del servidor: 10.4.32-MariaDB
-- Versión de PHP: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `k2h2`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `cliente`
--

CREATE TABLE `cliente` (
  `Id_Usuario` int(11) NOT NULL,
  `Nombre` varchar(24) DEFAULT NULL,
  `Apellido` varchar(24) DEFAULT NULL,
  `Correo` varchar(50) DEFAULT NULL,
  `Numero_Telefono` int(11) DEFAULT NULL,
  `Tipo_Usuario` varchar(15) DEFAULT NULL,
  `contraseña` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `cliente`
--

INSERT INTO `cliente` (`Id_Usuario`, `Nombre`, `Apellido`, `Correo`, `Numero_Telefono`, `Tipo_Usuario`, `contraseña`) VALUES
(0, 'yozd', NULL, 'yoxd@gmail.com', NULL, NULL, 'yo'),
(1983, 'Eric', 'Avalos', 'avaluzzg@gmail.com', 72217938, 'Cliente', '1'),
(1984, 'Rodrigo', 'Alizama', 'marial@gmail.com', 72217938, 'Cliente', '1'),
(1985, 'Juan', 'Perez', 'juanp@gmail.com', 72117938, 'Cliente', '1'),
(1986, 'Ana', 'Martinez', 'anam@gmail.com', 73217938, 'Cliente', '1'),
(1987, 'Luis', 'Garcia', 'luisg@hotmail.com', 72217939, 'Cliente', '1'),
(1988, 'Lucia', 'Hernandez', 'luciah@gmail.com', 72217338, 'Cliente', '1'),
(1989, 'Pedro', 'Diaz', 'pedrod@hotmail.com', 72217931, 'Cliente', '1'),
(1990, 'Laura', 'Morales', 'lauram@gmail.com', 72214938, 'Cliente', '1'),
(1991, 'Jorge', 'Ramirez', 'jorger@hotmail.com', 74217938, 'Cliente', '1'),
(1992, 'Sofia', 'Alvarez', 'sofiaal@gmail.com', 72917938, 'Cliente', '1');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `correctivo`
--

CREATE TABLE `correctivo` (
  `Id_Correctivo` int(11) NOT NULL,
  `Id_Servicio` int(11) DEFAULT NULL,
  `Sistema_Frenos` tinyint(1) DEFAULT NULL,
  `Bomba_Agua` tinyint(1) DEFAULT NULL,
  `Sistema_Electrico` tinyint(1) DEFAULT NULL,
  `Sistema_Direccion` tinyint(1) DEFAULT NULL,
  `Sistema_Transmision` tinyint(1) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `correctivo`
--

INSERT INTO `correctivo` (`Id_Correctivo`, `Id_Servicio`, `Sistema_Frenos`, `Bomba_Agua`, `Sistema_Electrico`, `Sistema_Direccion`, `Sistema_Transmision`) VALUES
(2000, 1, 1, 0, 1, 1, 0),
(2001, 2, 1, 1, 0, 1, 1),
(2003, 3, 0, 1, 1, 0, 1),
(2004, 4, 1, 0, 1, 1, 1),
(2005, 5, 0, 1, 1, 0, 0),
(2006, 6, 1, 1, 0, 1, 1),
(2007, 7, 1, 1, 1, 0, 1),
(2008, 8, 0, 1, 1, 1, 0),
(2009, 9, 1, 0, 1, 1, 1),
(2010, 10, 1, 1, 0, 1, 0);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `gerente`
--

CREATE TABLE `gerente` (
  `Id_Usuario` int(11) NOT NULL,
  `Nombre` varchar(24) DEFAULT NULL,
  `Apellido` varchar(24) DEFAULT NULL,
  `Correo` varchar(50) DEFAULT NULL,
  `Numero_Telefono` int(11) DEFAULT NULL,
  `Tipo_Usuario` varchar(15) DEFAULT NULL,
  `contraseña` varchar(150) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `gerente`
--

INSERT INTO `gerente` (`Id_Usuario`, `Nombre`, `Apellido`, `Correo`, `Numero_Telefono`, `Tipo_Usuario`, `contraseña`) VALUES
(100, 'Isabel', 'Ruiz', 'isabelr@gmail.com', 71839391, 'Gerente', '10'),
(101, 'Rodrigo', 'Lemus', 'rodrigud@hotmail.com', 71329391, 'Gerente', '1'),
(202, 'Rodrigo', 'Monge', 'elenao@gmail.com', 71829021, 'Gerente', '2'),
(303, 'Miguel', 'Rojas', 'miguelr@hotmail.com', 71829141, 'Gerente', '3'),
(404, 'Teresa', 'Vega', 'teresav@gmail.com', 71829390, 'Gerente', '4'),
(505, 'David', 'Salas', 'davids@hotmail.com', 71829396, 'Gerente', '5'),
(606, 'Paula', 'Cruz', 'paulac@hotmail.com', 71829394, 'Gerente', '6'),
(707, 'Alejandro', 'Nieto', 'alejandron@hotmail.com', 71819391, 'Gerente', '7'),
(808, 'Veronica', 'Lopez', 'veronical@gmail.com', 71829291, 'Gerente', '8'),
(909, 'Rafael', 'Dominguez', 'rafaeld@gmail.com', 71429391, 'Gerente', '9');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `preventivo`
--

CREATE TABLE `preventivo` (
  `Id_Preventivo` int(11) NOT NULL,
  `Id_Servicio` int(11) DEFAULT NULL,
  `Cambio_Aire` tinyint(1) DEFAULT NULL,
  `Cambio_Aceite` tinyint(1) DEFAULT NULL,
  `Niveles_Fluidos` tinyint(1) DEFAULT NULL,
  `Bateria` tinyint(1) DEFAULT NULL,
  `Cambio_Frenos` tinyint(1) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `preventivo`
--

INSERT INTO `preventivo` (`Id_Preventivo`, `Id_Servicio`, `Cambio_Aire`, `Cambio_Aceite`, `Niveles_Fluidos`, `Bateria`, `Cambio_Frenos`) VALUES
(1001, 2, 1, 1, 1, 1, 0),
(1002, 3, 0, 1, 1, 1, 1),
(1003, 4, 1, 0, 1, 1, 0),
(1004, 5, 1, 1, 0, 1, 1),
(1005, 6, 0, 1, 1, 0, 1),
(1006, 7, 1, 0, 1, 1, 1),
(1007, 8, 1, 1, 0, 1, 0),
(1008, 9, 0, 1, 1, 1, 1),
(1009, 10, 1, 1, 1, 0, 0),
(10000, 1, 1, 1, 1, 0, 0);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `producto`
--

CREATE TABLE `producto` (
  `Id_Producto` int(11) NOT NULL,
  `Precio` varchar(6) DEFAULT NULL,
  `Promocion` varchar(3) DEFAULT NULL,
  `Fecha_Produccion` date DEFAULT NULL,
  `Fecha_Vencimiento` date DEFAULT NULL,
  `Cantidad` varchar(6) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `producto`
--

INSERT INTO `producto` (`Id_Producto`, `Precio`, `Promocion`, `Fecha_Produccion`, `Fecha_Vencimiento`, `Cantidad`) VALUES
(234, '240', '1', '2024-09-29', '2024-10-30', '100'),
(10000, '100.00', '0.1', '2024-07-01', '2025-07-01', '200'),
(10001, '150.00', '0.1', '2024-07-02', '2025-07-02', '300'),
(10002, '120.00', '0.1', '2024-07-03', '2025-07-03', '400'),
(10003, '130.00', '0.2', '2024-07-04', '2025-07-04', '300'),
(10004, '110.00', '0.1', '2024-07-05', '2025-07-05', '250'),
(10005, '160.00', '0.0', '2024-07-06', '2025-07-06', '210'),
(10006, '140.00', '0.1', '2024-07-07', '2025-07-07', '150'),
(10007, '170.00', '0.2', '2024-07-08', '2025-07-08', '120'),
(10008, '180.00', '0.1', '2024-07-09', '2025-07-09', '300'),
(10009, '200.00', '0.1', '2024-07-10', '2025-07-10', '200'),
(100010, '234', '1', '2024-10-22', '2024-11-19', '200'),
(1000000, '200', '1', '2024-10-09', '2024-11-01', NULL),
(1000000123, '100', '2', '2024-10-08', '2024-11-07', '12');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `servicios`
--

CREATE TABLE `servicios` (
  `Id_Servicio` int(11) NOT NULL,
  `Precio` decimal(6,2) DEFAULT NULL,
  `Direccion` varchar(255) DEFAULT NULL,
  `Fecha_Inicio` date DEFAULT NULL,
  `Fecha_Finalizacion` date DEFAULT NULL,
  `Fecha_Solicitud` date DEFAULT NULL,
  `Promocion` float DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `servicios`
--

INSERT INTO `servicios` (`Id_Servicio`, `Precio`, `Direccion`, `Fecha_Inicio`, `Fecha_Finalizacion`, `Fecha_Solicitud`, `Promocion`) VALUES
(1, 2500.00, '123 Main St', '2024-08-01', '2024-08-03', '2024-07-28', 0.1),
(2, 3000.00, '456 Elm St', '2024-08-02', '2024-08-04', '2024-07-29', 0.05),
(3, 4500.00, '789 Maple Ave', '2024-08-03', '2024-08-05', '2024-07-30', 0.2),
(4, 5000.00, '101 Oak St', '2024-08-04', '2024-08-06', '2024-07-31', 0.15),
(5, 3500.00, '202 Pine St', '2024-08-05', '2024-08-07', '2024-08-01', 0.1),
(6, 4000.00, '303 Birch St', '2024-08-06', '2024-08-08', '2024-08-02', 0.1),
(7, 2800.00, '404 Cedar St', '2024-08-07', '2024-08-09', '2024-08-03', 0.05),
(8, 2600.00, '505 Ash St', '2024-08-08', '2024-08-10', '2024-08-04', 0.1),
(9, 3200.00, '606 Fir St', '2024-08-09', '2024-08-11', '2024-08-05', 0.1),
(10, 2900.00, '707 Spruce St', '2024-08-10', '2024-08-12', '2024-08-06', 0.05);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tecnico`
--

CREATE TABLE `tecnico` (
  `Id_Usuario` int(11) NOT NULL,
  `Nombre` varchar(24) DEFAULT NULL,
  `Apellido` varchar(24) DEFAULT NULL,
  `Correo` varchar(50) DEFAULT NULL,
  `Numero_Telefono` int(11) DEFAULT NULL,
  `Tipo_Usuario` varchar(15) DEFAULT NULL,
  `Activo` tinyint(1) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `tecnico`
--

INSERT INTO `tecnico` (`Id_Usuario`, `Nombre`, `Apellido`, `Correo`, `Numero_Telefono`, `Tipo_Usuario`, `Activo`) VALUES
(0, 'Josue', 'Palacios', 'josue@gmail.com', 12345678, NULL, 0),
(981, 'Andrea', 'Lopez', 'andreal@gmail.com', 72334501, 'Tecnico', 0),
(982, 'Fernando', 'Cruz', 'fernandoc@gmail.com', 73934511, 'Tecnico', 0),
(983, 'Ricardo', 'Torres', 'ricardot@gmail.com', 72934501, 'Tecnico', 0),
(984, 'Adriana', 'Mendez', 'adrianam@hotmail.com', 72034571, 'Tecnico', 1),
(985, 'Santiago', 'Gomez', 'santiagog@gmail.com', 72934561, 'Tecnico', 1),
(986, 'Monica', 'Silva', 'monicas@gmail.com', 72934521, 'Tecnico', 1),
(987, 'Alejandro', 'Ramirez', 'chepoe123@hotmail.com', 72934501, 'Tecnico', 1);

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `cliente`
--
ALTER TABLE `cliente`
  ADD PRIMARY KEY (`Id_Usuario`);

--
-- Indices de la tabla `correctivo`
--
ALTER TABLE `correctivo`
  ADD PRIMARY KEY (`Id_Correctivo`),
  ADD KEY `Id_Servicio` (`Id_Servicio`);

--
-- Indices de la tabla `gerente`
--
ALTER TABLE `gerente`
  ADD PRIMARY KEY (`Id_Usuario`);

--
-- Indices de la tabla `preventivo`
--
ALTER TABLE `preventivo`
  ADD PRIMARY KEY (`Id_Preventivo`),
  ADD KEY `Id_Servicio` (`Id_Servicio`);

--
-- Indices de la tabla `producto`
--
ALTER TABLE `producto`
  ADD PRIMARY KEY (`Id_Producto`);

--
-- Indices de la tabla `servicios`
--
ALTER TABLE `servicios`
  ADD PRIMARY KEY (`Id_Servicio`);

--
-- Indices de la tabla `tecnico`
--
ALTER TABLE `tecnico`
  ADD PRIMARY KEY (`Id_Usuario`);

--
-- Restricciones para tablas volcadas
--

--
-- Filtros para la tabla `correctivo`
--
ALTER TABLE `correctivo`
  ADD CONSTRAINT `correctivo_ibfk_1` FOREIGN KEY (`Id_Servicio`) REFERENCES `servicios` (`Id_Servicio`);

--
-- Filtros para la tabla `preventivo`
--
ALTER TABLE `preventivo`
  ADD CONSTRAINT `preventivo_ibfk_1` FOREIGN KEY (`Id_Servicio`) REFERENCES `servicios` (`Id_Servicio`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
