﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Reflection.Metadata;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Windows.Forms.DataVisualization.Charting;

namespace MiniProyectoSteven
{
    public partial class Humedales : Form
    {
        string[,] poblacion = new string[100, 100];
        string[,] eco;
        string[] recursos = new string[5];
        string[,] EstadoR = new string[100, 100];

        public Humedales(string[,] eco)
        {
            InitializeComponent();
            this.eco = eco;
            ConfigureChart();
        }

        private void ConfigureChart()
        {
            chart1.Series.Clear();
            chart1.ChartAreas[0].AxisX.Interval = 1;
            chart1.ChartAreas[0].AxisX.Title = "";
            chart1.ChartAreas[0].AxisY.Title = "Cantidad ";
        }

        private void Humedales_Load(object sender, EventArgs e)
        {

            chart1.Visible = false;
            for (int i = 1; i < 6; i++)
            {
                comboBox1.Items.Add(eco[i, 1]);
            }

            recursos[0] = "Mangle";
            recursos[1] = "Tule";
            recursos[2] = "Jacinto de agua";
            recursos[3] = "Lechuga de agua";
            recursos[4] = "Hierbas";
            for (int j = 0; j < recursos.Length; j++)
            {
                comboBox2.Items.Add(recursos[j]);
            }
        }




        private void UpdateChart()
        {
            chart1.Visible = true;
            chart1.Series.Clear();
            int columnas = poblacion.GetLength(1);
            int selectedIndex = comboBox1.SelectedIndex;
            int fechaIndex = 2 * selectedIndex;
            int cantidadIndex = 2 * selectedIndex + 1;

            for (int i = 0; i < columnas; i++)
            {
                if (!string.IsNullOrEmpty(poblacion[fechaIndex, i]) && !string.IsNullOrEmpty(poblacion[cantidadIndex, i]))
                {
                    var seriesName = $"Organismo {selectedIndex + 1} - Fecha: {poblacion[fechaIndex, i]}";
                    var series = new Series(seriesName)
                    {
                        ChartType = SeriesChartType.Column
                    };

                    series.Points.AddXY(poblacion[fechaIndex, i], Convert.ToInt32(poblacion[cantidadIndex, i]));
                    chart1.Series.Add(series);
                }
            }
        }
        private void UpdateChart2()
        {
            chart1.Visible = true;
            chart1.Series.Clear();
            int columnas = EstadoR.GetLength(1);
            int selectedIndex = comboBox2.SelectedIndex;
            int fechaIndex = 2 * selectedIndex;
            int cantidadIndex = 2 * selectedIndex + 1;

            for (int i = 0; i < columnas; i++)
            {
                if (!string.IsNullOrEmpty(EstadoR[fechaIndex, i]) && !string.IsNullOrEmpty(EstadoR[cantidadIndex, i]))
                {
                    var seriesName = $"Recurso {selectedIndex + 1} - Fecha: {EstadoR[fechaIndex, i]}";
                    var series = new Series(seriesName)
                    {
                        ChartType = SeriesChartType.Column
                    };

                    series.Points.AddXY(EstadoR[fechaIndex, i], Convert.ToInt32(EstadoR[cantidadIndex, i]));
                    chart1.Series.Add(series);
                }
            }
        }
  






        private void button5_Click_1(object sender, EventArgs e)
        {
            this.Close();


            Ecosistema ecositema = new Ecosistema();
            ecositema.Show();


        }

        private void button6_Click_1(object sender, EventArgs e)
        {
            if (comboBox1.SelectedIndex != -1 && comboBox2.SelectedIndex != -1)
            {
                MessageBox.Show("Error: Solo se puede seleccionar un combo box a la vez.");
                return;
            }

            if (comboBox1.SelectedIndex != -1)
            {
                int selectedIndex = comboBox1.SelectedIndex;
                int filas = poblacion.GetLength(1);

                for (int i = 0; i < filas; i++)
                {
                    poblacion[2 * selectedIndex, i] = null;
                    poblacion[2 * selectedIndex + 1, i] = null;
                }

                UpdateChart();
            }

            if (comboBox2.SelectedIndex != -1)
            {
                int selectedIndex = comboBox2.SelectedIndex;
                int filas = EstadoR.GetLength(1);

                for (int i = 0; i < filas; i++)
                {
                    EstadoR[2 * selectedIndex, i] = null;
                    EstadoR[2 * selectedIndex + 1, i] = null;
                }

                UpdateChart2();
            }
        }


        private void button1_Click_1(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(textBox1.Text))
            {
                MessageBox.Show("Debe ingresar el estado de la población del organismo");
                return;
            }

            if (!int.TryParse(textBox1.Text, out _))
            {
                MessageBox.Show("Solo se permiten valores enteros");
                return;
            }

            string fecha = dateTimePicker1.Value.ToString("dd/MM/yyyy");
            string cantidad = textBox1.Text;
            int selectedIndex = comboBox1.SelectedIndex;
            int columnas = poblacion.GetLength(1);

            DateTime fechaIngresada = DateTime.ParseExact(fecha, "dd/MM/yyyy", null);
            DateTime fechaUltima = DateTime.MinValue;


            for (int i = 0; i < columnas; i++)
            {
                if (!string.IsNullOrEmpty(poblacion[2 * selectedIndex, i]))
                {
                    DateTime fechaExistente = DateTime.ParseExact(poblacion[2 * selectedIndex, i], "dd/MM/yyyy", null);
                    if (fechaExistente > fechaUltima)
                    {
                        fechaUltima = fechaExistente;
                    }
                }
            }


            if (fechaIngresada <= fechaUltima)
            {
                MessageBox.Show("La fecha debe ser posterior a la última registrada.");
                return;
            }


            string[,] temp = new string[poblacion.GetLength(0), columnas + 1];
            for (int i = 0; i < poblacion.GetLength(0); i++)
            {
                for (int j = 0; j < columnas; j++)
                {
                    temp[i, j] = poblacion[i, j];
                }
            }

            int fechaIndex = 2 * selectedIndex;
            int cantidadIndex = 2 * selectedIndex + 1;

            temp[fechaIndex, columnas] = fecha;
            temp[cantidadIndex, columnas] = cantidad;

            poblacion = temp;

            UpdateChart();

        }

        private void button2_Click_1(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(textBox2.Text))
            {
                MessageBox.Show("Debe ingresar la cantidad del recurso disponible.");
                return;
            }

            if (!int.TryParse(textBox2.Text, out int cantidadDisponible))
            {
                MessageBox.Show("Solo se permiten valores enteros en la cantidad de recurso disponible.");
                return;
            }

            if (string.IsNullOrWhiteSpace(textBox3.Text))
            {
                MessageBox.Show("Debe ingresar la cantidad de recurso consumido.");
                return;
            }

            if (!int.TryParse(textBox3.Text, out int cantidadConsumida))
            {
                MessageBox.Show("Solo se permiten valores enteros en la cantidad de recurso consumido.");
                return;
            }

            if (cantidadConsumida > cantidadDisponible)
            {
                MessageBox.Show("La cantidad consumida no puede ser mayor que la cantidad disponible.");
                return;
            }

            string fecha = dateTimePicker2.Value.ToString("dd/MM/yyyy");
            int selectedIndex = comboBox2.SelectedIndex;
            int columnas = EstadoR.GetLength(1);

            DateTime fechaIngresada = DateTime.ParseExact(fecha, "dd/MM/yyyy", null);
            DateTime fechaUltima = DateTime.MinValue;

            for (int i = 0; i < columnas; i++)
            {
                if (!string.IsNullOrEmpty(EstadoR[2 * selectedIndex, i]))
                {
                    DateTime fechaExistente = DateTime.ParseExact(EstadoR[2 * selectedIndex, i], "dd/MM/yyyy", null);
                    if (fechaExistente > fechaUltima)
                    {
                        fechaUltima = fechaExistente;
                    }
                }
            }

            if (fechaIngresada <= fechaUltima)
            {
                MessageBox.Show("La fecha debe ser posterior a la última registrada.");
                return;
            }

            // Restar la cantidad consumida
            int cantidadFinal = cantidadDisponible - cantidadConsumida;

            // Guardar la nueva cantidad en EstadoR
            string[,] temp = new string[EstadoR.GetLength(0), columnas + 1];
            for (int i = 0; i < EstadoR.GetLength(0); i++)
            {
                for (int j = 0; j < columnas; j++)
                {
                    temp[i, j] = EstadoR[i, j];
                }
            }

            int fechaIndex = 2 * selectedIndex;
            int cantidadIndex = 2 * selectedIndex + 1;

            temp[fechaIndex, columnas] = fecha;
            temp[cantidadIndex, columnas] = cantidadFinal.ToString();

            EstadoR = temp;

            UpdateChart2();

            MessageBox.Show($"Se consumieron {cantidadConsumida} unidades de {recursos[selectedIndex]}. " +
                            $"Cantidad restante: {cantidadFinal}");
        }

    }
}
