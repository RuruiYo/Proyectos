﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MiniProyectoSteven
{

    public partial class Ecosistema : Form
    {
        string[,] eco = new string[6, 4];
        


        public Ecosistema()
        {
            InitializeComponent();
        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            string seleccion = comboBox1.SelectedItem.ToString();
            switch (seleccion)
            {
                case "Bosques":  Bosques bosques = new Bosques(eco); bosques.Show(); break;
                case "Humedales":  Humedales humedales = new Humedales(eco); humedales.Show(); break;
                case "Regiones costeras": RegionesCosteras regiones = new RegionesCosteras(eco); regiones.Show(); break;
                case "Cordillera": Cordilleras cordilleras = new Cordilleras(eco); cordilleras.Show(); break;

            }



        }

        private void Ecosistema_Load(object sender, EventArgs e)
        {
            // Ecosistemas
            eco[0, 0] = "Bosques";
            eco[0, 1] = "Humedales";
            eco[0, 2] = "Regiones costeras";
            eco[0, 3] = "Cordilleras";
            //organismos de bosques
            eco[1, 0] = "Tirano pirirí";
            eco[2, 0] = "León breñero";
            eco[3, 0] = "Ratones";
            eco[4, 0] = "Tepezcuintles";
            eco[5, 0] = "Yaguarundí";
            //organismos de humedales
            eco[1, 1] = "Cigueñuela Americana";
            eco[2, 1] = "Mapache";
            eco[3, 1] = "Cocodrilo Americano";
            eco[4, 1] = "Tilapia";
            eco[5, 1] = "Rana Leopardo";
            //organismos de Regiones costeras
            eco[1, 2] = "Garza Blanca";
            eco[2, 2] = "Mapache Cangrejero";
            eco[3, 2] = "Cocodrilo de Morelet";
            eco[4, 2] = "Langosta de mar";
            eco[5, 2] = "Tortuga marina";
            //organismos de Cordilleras
            eco[1, 3] = "Zorro Gris";
            eco[2, 3] = "Cusuco";
            eco[3, 3] = "Venado Cola Blanca";
            eco[4, 3] = "Guatusa";
            eco[5, 3] = "Taltuza";

        }

        private void button2_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}
