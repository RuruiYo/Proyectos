import pygame
import constantes
class Personaje():

    def __init__(self, x, y, animaciones, animaciones_ataque, tipo, energia):
        self.energia = energia
        self.flip = False
        self.animaciones = animaciones
        self.animaciones_ataque = animaciones_ataque
        self.atacando = False
        self.tiempo_actualizacion = pygame.time.get_ticks()
        self.tiempo_animacion = 80
        self.ventana_index = 0
        self.image = self.animaciones[self.ventana_index]
        self.actualizar_tiempo = pygame.time.get_ticks()
        self.shape = pygame.Rect(0, 0, 40, 40)
        self.shape.center = (x, y)
        self.tipo = tipo

    def dibujar(self, ventana):
        imagen_flip = pygame.transform.flip(self.image,self.flip, False)
        ventana.blit(imagen_flip, self.shape)

    def movimiento(self, distancia_x, distancia_y, exit_tile):
        posicion_pantalla = [0, 0]

        nivel_completado = False




        self.shape.x = self.shape.x + distancia_x

        self.shape.y = self.shape.y + distancia_y

        if distancia_x < 0:
                self.flip = True
        else:
            self.flip = False



        if self.tipo == 1:
            if exit_tile is not None:
                if exit_tile[1].colliderect(self.shape):
                    nivel_completado = True

                    print("Nivel completado")


            if self.shape.right > (constantes.WIDTH_VENTANA - constantes.LIMITE_PANTALLA):
                posicion_pantalla[0] = (constantes.WIDTH_VENTANA - constantes.LIMITE_PANTALLA) - self.shape.right

                self.shape.right = constantes.WIDTH_VENTANA - constantes.LIMITE_PANTALLA

            if self.shape.left < constantes.LIMITE_PANTALLA:
                posicion_pantalla[0] = constantes.LIMITE_PANTALLA - self.shape.left

                self.shape.left = constantes.LIMITE_PANTALLA

            if self.shape.top > (constantes.HEIGHT_VENTANA - constantes.LIMITE_PANTALLA):
                posicion_pantalla[1] = (constantes.HEIGHT_VENTANA - constantes.LIMITE_PANTALLA) - self.shape.top

                self.shape.top = constantes.HEIGHT_VENTANA - constantes.LIMITE_PANTALLA

            if self.shape.bottom < constantes.LIMITE_PANTALLA:
                posicion_pantalla[1] = constantes.LIMITE_PANTALLA - self.shape.bottom

                self.shape.bottom = constantes.LIMITE_PANTALLA

        return posicion_pantalla, nivel_completado



    def actualizar_imagen(self):

        if self.atacando:
            self.animar(self.animaciones_ataque)
        else:
            self.animar(self.animaciones)

    def animar(self, animaciones):
        tiempo_actual = pygame.time.get_ticks()
        if tiempo_actual - self.tiempo_actualizacion > self.tiempo_animacion:
            self.tiempo_actualizacion = tiempo_actual
            self.ventana_index += 1
            if self.ventana_index >= len(animaciones):
                self.ventana_index = 0
                if self.atacando:
                    self.atacando = False
            self.image = animaciones[self.ventana_index]

    def atacar(self):
        if not self.atacando:
            self.atacando = True
            self.ventana_index = 0
            self.tiempo_actualizacion = pygame.time.get_ticks()


    def lastimar(self, cantidad):
        self.energia -= cantidad




