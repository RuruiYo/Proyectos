import pygame
import constantes
from personaje import Personaje
import csv
from mundo import Mundo, Camera
from obstaculos import pozo_colosion, arbustos_colosion, lago_colosion, montaña_colosion, muro, mrocolision
from objetos import Objeto
from AgregarObjeto import encontrar_y_agregar_objeto1
from nivel2 import resetear_nivel
from nivel3 import resetear_nivel2
from  nivel4 import resetear_nivel3
pygame.init()

ventana = pygame.display.set_mode((constantes.WIDTH_VENTANA,
                                   constantes.HEIGHT_VENTANA))

pygame.display.set_caption("Dungeon of Darkness")

font_inicio = pygame.font.Font("Archivos/Fuente/DungeonFont.ttf", 30)
font_titulo = pygame.font.Font("Archivos/Fuente/DungeonFont.ttf", 70)


boton_jugar = pygame.Rect(constantes.WIDTH_VENTANA / 2 - 100, constantes.HEIGHT_VENTANA / 2 - 50, 200, 50)
boton_salir = pygame.Rect(constantes.WIDTH_VENTANA / 2 - 100, constantes.HEIGHT_VENTANA / 2 + 50, 200, 50)


texto_boton_jugar = font_inicio.render("Jugar", True, (0, 0, 0))
texto_boton_salir = font_inicio.render("Salir", True, (255, 255, 255))

def pantalla_inicio():

    ventana.fill(constantes.COLOR_FONDO)
    dibujar_texto = font_titulo.render("Dungeon of Darkness", True, (255, 255, 255), )
    texto_titulo = dibujar_texto.get_rect(center=(constantes.WIDTH_VENTANA / 2, constantes.HEIGHT_VENTANA / 2 - 120))
    ventana.blit(dibujar_texto, texto_titulo)
    pygame.draw.rect(ventana, (156, 223, 219), boton_jugar)
    pygame.draw.rect(ventana, (13, 68, 65), boton_salir)

    ventana.blit(texto_boton_jugar, (boton_jugar.x + 50, boton_jugar.y + 10))
    ventana.blit(texto_boton_salir, (boton_salir.x + 50, boton_salir.y + 10))
    pygame.display.update()

boton_volver_inicio = pygame.Rect(constantes.WIDTH_VENTANA / 2 -100, constantes.HEIGHT_VENTANA / 2 + 50, 200, 50)
texto_boton_volver_inicio = font_inicio.render("Volver al Inicio", True, (255, 255, 255))

def pantalla_game_over():
    ventana.fill((0, 0, 0))
    dibujar_texto = font_titulo.render("Game Over", True, (255, 0, 0))
    texto_titulo = dibujar_texto.get_rect(center=(constantes.WIDTH_VENTANA / 2, constantes.HEIGHT_VENTANA / 2 - 120))
    ventana.blit(dibujar_texto, texto_titulo)

    pygame.draw.rect(ventana, (13, 68, 65), boton_volver_inicio)
    ventana.blit(texto_boton_volver_inicio, (boton_volver_inicio.x + 10, boton_volver_inicio.y + 10))
    pygame.display.update()

def pantalla_ganaste():
    ventana.fill((0, 0, 0))
    dibujar_texto = font_titulo.render("Ganaste", True, (255, 0, 0))
    texto_titulo = dibujar_texto.get_rect(center=(constantes.WIDTH_VENTANA / 2, constantes.HEIGHT_VENTANA / 2 - 120))
    ventana.blit(dibujar_texto, texto_titulo)

    pygame.draw.rect(ventana, (13, 68, 65), boton_salir)
    ventana.blit(texto_boton_salir, (boton_salir.x + 50, boton_salir.y + 10))

    pygame.display.update()




nivel = 1

corazon_vacio = pygame.image.load("Archivos/Imágenes/Items/Vacio.png")
corazon_vacio = pygame.transform.scale(corazon_vacio, (corazon_vacio.get_width() * constantes.ESCALA_CORAZONES, corazon_vacio.get_height() * constantes.ESCALA_CORAZONES))

corazon_medio = pygame.image.load("Archivos/Imágenes/Items/Medio.png")
corazon_medio = pygame.transform.scale(corazon_medio, (corazon_medio.get_width() * constantes.ESCALA_CORAZONES, corazon_medio.get_height() * constantes.ESCALA_CORAZONES))

corazon_lleno = pygame.image.load("Archivos/Imágenes/Items/Lleno.png")
corazon_lleno = pygame.transform.scale(corazon_lleno, (corazon_lleno.get_width() * constantes.ESCALA_CORAZONES, corazon_lleno.get_height() * constantes.ESCALA_CORAZONES))

animaciones = []

for i in range(1, 9):
    img = pygame.image.load(f"Archivos/Imágenes/CABALLERO/Fig.{i}.png")
    img = pygame.transform.scale(img,
        (img.get_width()*constantes.ESCALA_PERSONAJE,
         img.get_height()*constantes.ESCALA_PERSONAJE))
    animaciones.append(img)



    animaciones_ataque = []
    for i in range(1, 9):
        img = pygame.image.load(f"Archivos/Imágenes/CABALLERO/Ataque Caballero/CAB_ATAQUE ({i}).png")
        img = pygame.transform.scale(img, (
        img.get_width() * constantes.ESCALA_PERSONAJE, img.get_height() * constantes.ESCALA_PERSONAJE))
        animaciones_ataque.append(img)

animaciones2 = []

for i in range (1, 8):
    img = pygame.image.load(f"Archivos/Imágenes/Arbol/Arbol ({i}).png")
    img = pygame.transform.scale(img,(img.get_width() * constantes.ESCALA_PERSONAJE, img.get_height() * constantes.ESCALA_PERSONAJE))
    animaciones2.append(img)

animaciones3 = []
for i in range(1, 9):
    png = pygame.image.load(f"Archivos/Imágenes/SAMURAI/fig{i}.png")
    png = pygame.transform.scale(png, (
        png.get_width()*constantes.ESCALA_PERSONAJE,
        png.get_height()*constantes.ESCALA_PERSONAJE))
    animaciones3.append(png)

animaciones4 = []
for i in range(1, 9):
    png = pygame.image.load(f"Archivos/Imágenes/MagoOscuro/fila-1-columna-{i}.png")
    png = pygame.transform.scale(png, (
        png.get_width()*constantes.ESCALA_PERSONAJE,
        png.get_height()*constantes.ESCALA_PERSONAJE))
    animaciones4.append(png)

animaciones5 = []
for i in range(1, 9):
    png = pygame.image.load(f"Archivos/Imágenes/Ogro/PineTools.com_files/fila-1-columna-{i}.png")
    png = pygame.transform.scale(png,
        (png.get_width()*constantes.ESCALA_PERSONAJE2,
         png.get_height()*constantes.ESCALA_PERSONAJE2))
    animaciones5.append(png)




pocion_roja = pygame.image.load("Archivos/Imágenes/Items/Pocion.png")
pocion_roja = pygame.transform.scale(pocion_roja,(pocion_roja.get_width() * constantes.ESCALA_POCION, pocion_roja.get_height() * constantes.ESCALA_POCION))



world_data=[]

for fila in range(constantes.FILAS):
    filas = [1] * constantes.COLUMNAS
    world_data.append(filas)

with open('Tileset/Mapatile2.csv', newline='') as csvfile:
    reader = csv.reader(csvfile, delimiter=';')
    for x, fila in enumerate(reader):
        for y, columna in enumerate(fila):
            world_data[x][y] = int(columna)

def dibujar_grid():
    for x in range(constantes.COLUMNAS):
        pygame.draw.line(ventana, (255, 255, 255),
                         (x*50, 0), (x*50, constantes.HEIGHT_VENTANA))
        pygame.draw.line(ventana, (255, 255, 255), (0, x*50),
                         (constantes.WIDTH_VENTANA, x*50))

tile_list = []
for x in range(300):
    tile_image = pygame.image.load(f"Tileset/Mapa1set/Mundo ({x+1}).png")
    tile_image = pygame.transform.scale(tile_image, (50, 50))
    tile_list.append(tile_image)

world = Mundo(nivel)
world.process_data(world_data, tile_list)

def vida_jugador():
    c_medio_dibujado = False
    for i in range(4):
        if jugador.energia >= ((i+1)*25):
            ventana.blit(corazon_lleno, (5+i*50, 5))
        elif jugador.energia % 25 > 0 and c_medio_dibujado == False:
            ventana.blit(corazon_medio, (5 + i * 50, 5))
            c_medio_dibujado = True

        else:
            ventana.blit(corazon_vacio, (5 + i * 50, 5))


jugador = Personaje(100, 260, animaciones, animaciones_ataque, 1, 100)
villano = Personaje(1153, 204, animaciones2, False, 0, 150)
samurai = Personaje(400, 100, animaciones3, False,0,200)
mago = Personaje(400, 100, animaciones4, False, 0, 250)
ogro = Personaje(400, 100, animaciones5, False, 0, 130)

grupo_objetos = pygame.sprite.Group()
pocion, tile_pos = encontrar_y_agregar_objeto1(world_data, 56, pocion_roja)
if pocion:
    grupo_objetos.add(pocion)
pocion2, tile_pos2 = encontrar_y_agregar_objeto1(world_data, 173, pocion_roja)
if pocion2:
    grupo_objetos.add(pocion2)



mover_arriba = False
mover_abajo = False
mover_izquierda = False
mover_derecha = False

camera = Camera(constantes.WIDTH_VENTANA, constantes.HEIGHT_VENTANA, constantes.COLUMNAS, constantes.FILAS)

run = True

reloj = pygame.time.Clock()

tecla_r_presionada = False
visible = True

mostrar_inicio = True
game_over = False
ganaste = False



while run == True:
    if mostrar_inicio == True:
        pantalla_inicio()
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                run = False
            if event.type == pygame.MOUSEBUTTONDOWN and boton_jugar.collidepoint(event.pos):
                mostrar_inicio = False
                game_over = False
                jugador.energia = 100
                jugador.shape.topleft = (150, 150)
                villano.energia = 100
                ogro.energia = 130
                mago.energia = 250
                samurai.energia = 200
                villano.shape.topleft = (300, 150)
                visible = True
                camera.offset = [0, 0]


            if event.type == pygame.MOUSEBUTTONDOWN and boton_salir.collidepoint(event.pos):
                run = False

    elif game_over:
        pantalla_game_over()
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                run = False
            if event.type == pygame.MOUSEBUTTONDOWN and boton_volver_inicio.collidepoint(event.pos):
                mostrar_inicio = True
                game_over = False
                jugador.energia = 100
                jugador.shape.topleft = (150, 150)
                villano.energia = 100
                ogro.energia = 130
                mago.energia = 250
                samurai.energia = 200
                villano.shape.topleft = (300, 150)
                visible = True
                camera.offset = [0, 0]



    elif ganaste:
        pantalla_ganaste()
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                run = False
            if event.type == pygame.MOUSEBUTTONDOWN and boton_salir.collidepoint(event.pos):
                run = False
                mostrar_inicio = False
                ganaste = False
                jugador.energia = 100
                jugador.shape.topleft = (150, 150)
                villano.energia = 100

                villano.shape.topleft = (300, 150)
                visible = True
                camera.offset = [0, 0]

    else:

        reloj.tick(constantes.FPS)

        ventana.fill(constantes.COLOR_FONDO)

        dibujar_grid()
        distancia_x = 0
        distancia_y = 0


        if mover_derecha:
            distancia_x = constantes.VELOCIDAD

        if mover_izquierda:
            distancia_x = -constantes.VELOCIDAD

        if mover_arriba:
            distancia_y = -constantes.VELOCIDAD

        if mover_abajo:
            distancia_y = constantes.VELOCIDAD

        jugador_pos_mundo_x = jugador.shape.x - camera.offset[0]
        jugador_pos_mundo_y = jugador.shape.y - camera.offset[1]

        print(f"Posición del jugador en el mundo: x={jugador_pos_mundo_x},y={jugador_pos_mundo_y}")

        if nivel ==1:
            distancia_x, distancia_y = pozo_colosion(jugador_pos_mundo_x, jugador_pos_mundo_y, distancia_x, distancia_y)
            distancia_x, distancia_y = arbustos_colosion(jugador_pos_mundo_x, jugador_pos_mundo_y, distancia_x, distancia_y)

        if nivel == 2:
            distancia_x, distancia_y = lago_colosion(jugador_pos_mundo_x, jugador_pos_mundo_y, distancia_x, distancia_y)
            distancia_x, distancia_y = montaña_colosion(jugador_pos_mundo_x, jugador_pos_mundo_y, distancia_x, distancia_y)

        if nivel == 3:
            distancia_x, distancia_y = muro(jugador_pos_mundo_x, jugador_pos_mundo_y, distancia_x, distancia_y)
            distancia_x, distancia_y = mrocolision(jugador_pos_mundo_x, jugador_pos_mundo_y, distancia_x, distancia_y)





        camera.move(-distancia_x, - distancia_y)
        world.uptade(camera)

        posicion_pantalla,nivel_completado = jugador.movimiento(distancia_x, distancia_y, world.exit_tile)
        print(nivel_completado)
        print(nivel)


        jugador.actualizar_imagen()
        world.draw(ventana)
        grupo_objetos.update(jugador)
        if pocion:
            pocion.rect.topleft = (tile_pos[0] + camera.offset[0], tile_pos[1] + camera.offset[1])
        if pocion2:
            pocion2.rect.topleft = (tile_pos2[0] + camera.offset[0], tile_pos2[1] + camera.offset[1])



        jugador.dibujar(ventana)

        vida_jugador()

        grupo_objetos.draw(ventana)

        if nivel_completado == True and nivel == 1 and jugador.energia > 50:
            nivel, world, jugador, grupo_objetos, camera = resetear_nivel(jugador, grupo_objetos, camera)

            grupo_objetos = pygame.sprite.Group()

            pocion, tile_pos = encontrar_y_agregar_objeto1(world_data, 56, pocion_roja)
            grupo_objetos.add(pocion)

            pocion2, tile_pos2 = encontrar_y_agregar_objeto1(world_data, 173, pocion_roja)
            grupo_objetos.add(pocion2)

        if nivel_completado == True and nivel == 2 and samurai.energia <= 0:
            nivel, world, jugador, grupo_objetos, camera = resetear_nivel2(jugador, grupo_objetos, camera)

        if nivel_completado == True and nivel == 3 and mago.energia <= 0:
            nivel, world, jugador, grupo_objetos, camera = resetear_nivel3(jugador, grupo_objetos, camera)

        if game_over == True:
            nivel, world, jugador, grupo_objetos, camera = resetear_nivel(jugador, grupo_objetos, camera)




        if nivel == 1 and visible == True:


            if jugador.shape.colliderect(villano.shape) and tecla_r_presionada:
                print("Colison detectada")
                print("Tecla 'o' presionada")
                villano.lastimar(10)
                print(f"Villano energia: {villano.energia}")

            if villano.energia > 0:

                if jugador.shape.colliderect(villano.shape):
                    print("Colision directa")
                    jugador.lastimar(0.75)
                    print(f"Jugador energia: {jugador.energia}")

            else:
                visible = False

        if nivel == 1 and visible == True:
            ene_dx = 0
            ene_dy = 0

            if villano.shape.centerx > jugador.shape.centerx:
                ene_dx = -1
            if villano.shape.centerx < jugador.shape.centerx:
                ene_dx = 1
            if villano.shape.centery > jugador.shape.centery:
                ene_dy = -1
            if villano.shape.centery < jugador.shape.centery:
                ene_dy = 1

            villano.shape.x += ene_dx
            villano.shape.y += ene_dy

            villano.actualizar_imagen()

            posicion_pantalla, nivel_completado = villano.movimiento(ene_dx, ene_dy, None)

            villano.dibujar(ventana)



    if nivel == 2 and samurai.energia > 0:
        visible = True

    if nivel == 2 and visible == True:

        if jugador.shape.colliderect(samurai.shape) and tecla_r_presionada:
            print("Colison detectada")
            print("Tecla 'o' presionada")
            samurai.lastimar(10)
            print(f"Villano energia: {samurai.energia}")

        if samurai.energia > 0:

            if jugador.shape.colliderect(samurai.shape):
                print("Colision directa")
                jugador.lastimar(0.85)
                print(f"Jugador energia: {jugador.energia}")

        else:
            visible = False



    if nivel == 2 and visible == True:
        ene_dx = 0
        ene_dy = 0


        if samurai.shape.centerx > jugador.shape.centerx:
            ene_dx = -1
        if samurai.shape.centerx < jugador.shape.centerx:
            ene_dx = 1
        if samurai.shape.centery > jugador.shape.centery:
            ene_dy = -1
        if samurai.shape.centery < jugador.shape.centery:
            ene_dy = 1

        samurai.shape.x += ene_dx
        samurai.shape.y += ene_dy

        samurai.actualizar_imagen()

        posicion_pantalla, nivel_completado = samurai.movimiento(ene_dx, ene_dy, None)

        samurai.dibujar(ventana)


    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            run = False

        if event.type == pygame.KEYDOWN:
            if event.key == pygame.K_a:
                mover_izquierda = True

            if event.key == pygame.K_d:
                mover_derecha = True

            if event.key == pygame.K_w:
                mover_arriba = True

            if event.key == pygame.K_s:
                mover_abajo = True

            if event.key == pygame.K_r:
                tecla_r_presionada = True
                jugador.atacar()

        if event.type == pygame.KEYUP:
            if event.key == pygame.K_a:
                mover_izquierda = False
            if event.key == pygame.K_d:
                mover_derecha = False
            if event.key == pygame.K_w:
                mover_arriba = False
            if event.key == pygame.K_s:
                mover_abajo = False

            if event.key == pygame.K_r:
                tecla_r_presionada = False

        pygame.display.update()


    if nivel == 3 and mago.energia > 0:
        visible = True

    if nivel == 3 and visible == True:

        if jugador.shape.colliderect(mago.shape) and tecla_r_presionada:
            print("Colison detectada")
            print("Tecla 'o' presionada")
            mago.lastimar(10)
            print(f"Villano energia: {mago.energia}")

        if mago.energia > 0:

            if jugador.shape.colliderect(mago.shape):
                print("Colision directa")
                jugador.lastimar(0.95)
                print(f"Jugador energia: {jugador.energia}")

        else:
            visible = False

    if nivel == 3 and visible == True:
        ene_dx = 0
        ene_dy = 0

        if mago.shape.centerx > jugador.shape.centerx:
            ene_dx = -1
        if mago.shape.centerx < jugador.shape.centerx:
            ene_dx = 1
        if mago.shape.centery > jugador.shape.centery:
            ene_dy = -1
        if mago.shape.centery < jugador.shape.centery:
            ene_dy = 1

        mago.shape.x += ene_dx
        mago.shape.y += ene_dy

        mago.actualizar_imagen()

        posicion_pantalla, nivel_completado = mago.movimiento(ene_dx, ene_dy, None)

        mago.dibujar(ventana)

    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            run = False

        if event.type == pygame.KEYDOWN:
            if event.key == pygame.K_a:
                mover_izquierda = True

            if event.key == pygame.K_d:
                mover_derecha = True

            if event.key == pygame.K_w:
                mover_arriba = True

            if event.key == pygame.K_s:
                mover_abajo = True

            if event.key == pygame.K_r:
                tecla_r_presionada = True
                jugador.atacar()

        if event.type == pygame.KEYUP:
            if event.key == pygame.K_a:
                mover_izquierda = False
            if event.key == pygame.K_d:
                mover_derecha = False
            if event.key == pygame.K_w:
                mover_arriba = False
            if event.key == pygame.K_s:
                mover_abajo = False

            if event.key == pygame.K_r:
                tecla_r_presionada = False


    if jugador.energia <=0:
        game_over = True

    pygame.display.update()

    if nivel == 4 and ogro.energia > 0:
        visible = True

    if nivel == 4 and visible == True:

        if jugador.shape.colliderect(ogro.shape) and tecla_r_presionada:
            print("Colison detectada")
            print("Tecla 'o' presionada")
            ogro.lastimar(10)
            print(f"Villano energia: {ogro.energia}")

        if ogro.energia > 0:

            if jugador.shape.colliderect(ogro.shape):
                print("Colision directa")
                jugador.lastimar(0.05)
                print(f"Jugador energia: {jugador.energia}")

        else:
            visible = False

    if nivel == 4 and visible == True:
        ene_dx = 0
        ene_dy = 0

        if ogro.shape.centerx > jugador.shape.centerx:
            ene_dx = -1
        if ogro.shape.centerx < jugador.shape.centerx:
            ene_dx = 1
        if ogro.shape.centery > jugador.shape.centery:
            ene_dy = -1
        if ogro.shape.centery < jugador.shape.centery:
            ene_dy = 1

        ogro.shape.x += ene_dx
        ogro.shape.y += ene_dy

        ogro.actualizar_imagen()

        posicion_pantalla, nivel_completado = ogro.movimiento(ene_dx, ene_dy, None)

        ogro.dibujar(ventana)

    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            run = False

        if event.type == pygame.KEYDOWN:
            if event.key == pygame.K_a:
                mover_izquierda = True

            if event.key == pygame.K_d:
                mover_derecha = True

            if event.key == pygame.K_w:
                mover_arriba = True

            if event.key == pygame.K_s:
                mover_abajo = True

            if event.key == pygame.K_r:
                tecla_r_presionada = True
                jugador.atacar()

        if event.type == pygame.KEYUP:
            if event.key == pygame.K_a:
                mover_izquierda = False
            if event.key == pygame.K_d:
                mover_derecha = False
            if event.key == pygame.K_w:
                mover_arriba = False
            if event.key == pygame.K_s:
                mover_abajo = False

            if event.key == pygame.K_r:
                tecla_r_presionada = False


    if jugador.energia <=0:
        game_over = True

    if ogro.energia <= 0:
        ganaste = True

    pygame.display.update()

pygame.quit()
