import pygame

class Mundo():
    def __init__(self, nivel):
        self.map_tiles = []
        self.exit_tile = None
        self.nivel = nivel


    def process_data(self, data, tile_list):
        self.level_length = len(data)

        for y, row in enumerate(data):
            for x, tile in enumerate(row):
                image = tile_list[tile]
                image_rect = image.get_rect()
                image_x = x*50
                image_y = y*50
                image_rect = pygame.Rect(image_x, image_y,50,50)
                title_data = (image, image_rect, image_x, image_y)

                if self.nivel == 1 and tile == 87:
                    self.exit_tile = title_data
                elif self.nivel == 2 and tile == 79:
                    self.exit_tile = title_data
                elif self.nivel == 3 and tile == 83:
                    self.exit_tile = title_data





                self.map_tiles.append(title_data)


    def uptade(self,camera):
        for tile in self.map_tiles:
            tile[1].x = tile[2] + camera.offset[0]
            tile[1].y = tile[3] + camera.offset[1]

    def draw(self, surface):
        for title in self.map_tiles:
            surface.blit(title[0], title[1])

class Camera:
    def __init__(self, screen_whidth, screen_height, world_whidth, world_height):
        self.offset = [0, 0]
        self.screen_whidth = screen_whidth
        self.screen_height = screen_height
        self.world_whidth = world_whidth
        self.world_height = world_height
        self.offset = [0, 0]

    def reset(self):
        self.offset = [0, 0]


    def move(self, dx, dy):
        self.offset[0]=min(0, max(-(self.world_whidth * 50 - self.screen_whidth), self.offset[0]+dx))
        self.offset[1] = min(0, max(-(self.world_height * 50 - self.screen_height), self.offset[1] + dy))
