def pozo_colosion(jugador_pos_mundo_x, jugador_pos_mundo_y, distancia_x, distancia_y):
    if 728 <= jugador_pos_mundo_x <= 735 and 60 <= jugador_pos_mundo_y <= 132:
        distancia_x -= 3
    if 878 <= jugador_pos_mundo_x <= 885 and 60 <= jugador_pos_mundo_y <= 132:
        distancia_x += 3
    if 750 <= jugador_pos_mundo_x <= 870 and 125 <= jugador_pos_mundo_y <= 130:
        distancia_y += 3
    if 738 <= jugador_pos_mundo_x <= 862 and 200 <= jugador_pos_mundo_y <= 210:
        distancia_y -= 3
    if 750 <= jugador_pos_mundo_x <= 756 and 215 <= jugador_pos_mundo_y <= 370:
        distancia_x -= 3
    if 870 <= jugador_pos_mundo_x <= 880 and 208 <= jugador_pos_mundo_y <= 344:
        distancia_x += 3
    if 748 <= jugador_pos_mundo_x <= 844 and 360 <= jugador_pos_mundo_y <= 375:
        distancia_y += 3

    return distancia_x, distancia_y
def arbustos_colosion(jugador_pos_mundo_x, jugador_pos_mundo_y, distancia_x, distancia_y):
    if 1230 <= jugador_pos_mundo_x <= 1250 and 270 <= jugador_pos_mundo_y <= 392:
        distancia_x -= 3
    if 870 <= jugador_pos_mundo_x <= 1228 and 240 <= jugador_pos_mundo_y <= 245:
        distancia_y -= 3
    if 876 <= jugador_pos_mundo_x <= 1225 and 340 <= jugador_pos_mundo_y <= 350:
        distancia_y += 3

    if 870 <= jugador_pos_mundo_x <= 1230 and 140 <= jugador_pos_mundo_y <= 150:
        distancia_y += 3
    if 1240 <= jugador_pos_mundo_x <= 1250 and 60 <= jugador_pos_mundo_y <= 130:
        distancia_x += 3
    return distancia_x, distancia_y

def lago_colosion(jugador_pos_mundo_x, jugador_pos_mundo_y, distancia_x, distancia_y):
    if 430 <= jugador_pos_mundo_x <= 440 and 120 <= jugador_pos_mundo_y <= 276:
            distancia_x -= 3
    if 680 <= jugador_pos_mundo_x <= 690 and 120 <= jugador_pos_mundo_y <= 276:
            distancia_x += 3
    if 452 <= jugador_pos_mundo_x <= 668 and 270 <= jugador_pos_mundo_y <= 280:
            distancia_y += 3
    if 452 <= jugador_pos_mundo_x <= 668 and 100 <= jugador_pos_mundo_y <= 110:
            distancia_y -= 3
    return distancia_x, distancia_y

def montaña_colosion(jugador_pos_mundo_x, jugador_pos_mundo_y, distancia_x, distancia_y):
    if 1170 <= jugador_pos_mundo_x <= 1190 and 60 <= jugador_pos_mundo_y <= 134:
        distancia_x -= 3
    if 1240 <= jugador_pos_mundo_x <= 1250 and 60 <= jugador_pos_mundo_y <= 134:
        distancia_x += 3
    if 1190 <= jugador_pos_mundo_x <= 1234 and 130 <= jugador_pos_mundo_y <= 140:
        distancia_y += 3
    return distancia_x, distancia_y

def muro(jugador_pos_mundo_x, jugador_pos_mundo_y, distancia_x, distancia_y):
    if 153 <= jugador_pos_mundo_x <= 165 and 99 <= jugador_pos_mundo_y <= 253:
        distancia_x -= 3
    if 298 <= jugador_pos_mundo_x <= 300 and 165 <= jugador_pos_mundo_y <= 300:
        distancia_x += 3
    if 159 <= jugador_pos_mundo_x <= 231 and 99 <= jugador_pos_mundo_y <= 175:
        distancia_y += 3
    return distancia_x, distancia_y

def mrocolision(jugador_pos_mundo_x, jugador_pos_mundo_y, distancia_x, distancia_y):
    if 372 <= jugador_pos_mundo_x <= 382 and 242 <= jugador_pos_mundo_y <= 352:
        distancia_x -= 5
    if 436 <= jugador_pos_mundo_x <= 366 and 248 <= jugador_pos_mundo_y <= 352:
        distancia_x += 5
    if 442 <= jugador_pos_mundo_x <= 450 and 254 <= jugador_pos_mundo_y <= 400:
        distancia_y += 5
    return distancia_x, distancia_y

   

