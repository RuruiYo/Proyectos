import pygame
import constantes
from personaje import Personaje
import csv
from mundo import Mundo, Camera
from objetos import Objeto
from AgregarObjeto import encontrar_y_agregar_objeto1



def resetear_nivel2(jugador, grupo_objetos, camera):
    nivel = 3


    camera.reset()

    world_data = []
    for fila in range(constantes.FILAS):
        filas = [1] * constantes.COLUMNAS
        world_data.append(filas)

    with open(r'Tileset/Mapatile2.csv', newline='') as csvfile:
        reader = csv.reader(csvfile, delimiter=';')
        for x, fila in enumerate(reader):
            for y, columna in enumerate(fila):
                world_data[x][y] = int(columna)

    tile_list = []
    for x in range(300):
        tile_image = pygame.image.load(f"Tileset/Mapa3Set/PineTools.com_files/Mundo1 ({x + 1}).png")
        tile_image = pygame.transform.scale(tile_image, (50, 50))
        tile_list.append(tile_image)

    world = Mundo(nivel)
    world.process_data(world_data, tile_list)

    jugador.shape.center = (150, 150)

    return nivel, world, jugador, grupo_objetos, camera