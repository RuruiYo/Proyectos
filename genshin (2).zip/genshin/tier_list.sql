-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 28-02-2025 a las 02:17:51
-- Versión del servidor: 10.4.32-MariaDB
-- Versión de PHP: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `tier_list`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `personajes`
--

CREATE TABLE `personajes` (
  `id` int(11) NOT NULL,
  `nombre` varchar(255) NOT NULL,
  `elemento` varchar(50) NOT NULL,
  `imagen_url` varchar(255) NOT NULL,
  `categoria` varchar(5) NOT NULL,
  `tipo_de_arma` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `personajes`
--

INSERT INTO `personajes` (`id`, `nombre`, `elemento`, `imagen_url`, `categoria`, `tipo_de_arma`) VALUES
(1, 'Xiangling', 'Pyro', 'https://i2.wp.com/images.genshin-builds.com/genshin/characters/xiangling/image.png?strip=all&quality=75&w=256', 'S', 'Lanza'),
(7, 'Furina', 'Hydro', 'https://i2.wp.com/images.genshin-builds.com/genshin/characters/furina/image.png?strip=all&quality=75&w=256', 'S', 'Espada'),
(8, 'Hu Tao', 'Pyro', 'https://i2.wp.com/images.genshin-builds.com/genshin/characters/hu_tao/image.png?strip=all&quality=75&w=256', 'A', 'Lanza'),
(9, 'Ayaka', 'Cryo', 'https://celestiabuilds.com/wp-content/uploads/2021/07/Character_Ayaka.png', 'A', 'Espada'),
(10, 'Beidou', 'Electro', 'https://i2.wp.com/images.genshin-builds.com/genshin/characters/beidou/image.png?strip=all&quality=100', 'B', 'Mandoble'),
(12, 'Ningguang', 'Geo', 'https://i2.wp.com/images.genshin-builds.com/genshin/characters/ningguang/image.png?strip=all&quality=75&w=384', 'C', 'Catalizador'),
(13, 'Diluc', 'Pyro', 'https://i2.wp.com/images.genshin-builds.com/genshin/characters/diluc/image.png?strip=all&quality=100', 'B', 'Mandoble'),
(14, 'Jean', 'Anemo', 'https://i2.wp.com/images.genshin-builds.com/genshin/characters/jean/image.png?strip=all&quality=75&w=256', 'A', 'Espada'),
(15, 'Neuvillette', 'Hydro', 'https://i2.wp.com/images.genshin-builds.com/genshin/characters/neuvillette/image.png?strip=all&quality=75&w=256', 'S', 'Catalizador');

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `personajes`
--
ALTER TABLE `personajes`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `personajes`
--
ALTER TABLE `personajes`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
