<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tier List</title>
    <link rel="stylesheet" href="style.css">
</head>
<style>
    .filters {
    display: flex;
    justify-content: center;
    gap: 20px;
    margin-bottom: 20px;
}

.filter {
    display: flex;
    gap: 10px;
    flex-wrap: wrap;
}

.filter-btn {
    padding: 10px;
    background-color: #333;
    color: white;
    border: 1px solid #fff;
    cursor: pointer;
    border-radius: 5px;
    font-size: 14px;
    transition: background-color 0.3s ease;
}

.filter-btn:hover {
    background-color: #444;
}

.selected-filters {
    margin-top: 20px;
    font-size: 18px;
    color: #f1c40f;
}
    </style>
<body>

    <!-- Filtros de Elementos y Armas -->
    <div class="filters">
        <div class="filter" id="element-filters">
            <button class="filter-btn" onclick="toggleFilter('Pyro', 'element')">Pyro</button>
            <button class="filter-btn" onclick="toggleFilter('Hydro', 'element')">Hydro</button>
            <button class="filter-btn" onclick="toggleFilter('Electro', 'element')">Electro</button>
            <button class="filter-btn" onclick="toggleFilter('Geo', 'element')">Geo</button>
            <button class="filter-btn" onclick="toggleFilter('Anemo', 'element')">Anemo</button>
            <button class="filter-btn" onclick="toggleFilter('Cryo', 'element')">Cryo</button>
            <button class="filter-btn" onclick="toggleFilter('Dendro', 'element')">Dendro</button>
        </div>
        <div class="filter" id="weapon-filters">
            <button class="filter-btn" onclick="toggleFilter('Arco', 'weapon')">Arco</button>
            <button class="filter-btn" onclick="toggleFilter('Espada', 'weapon')">Espada</button>
            <button class="filter-btn" onclick="toggleFilter('Catalizador', 'weapon')">Catalizador</button>
            <button class="filter-btn" onclick="toggleFilter('Mandoble', 'weapon')">Mandoble</button>
            <button class="filter-btn" onclick="toggleFilter('Lanza', 'weapon')">Lanza</button>
        </div>
    </div>

    <!-- Indicador de filtros activos -->
    <div class="selected-filters" id="selected-filters">
        Filtros Activos: Ninguno
    </div>

    <!-- Botón para cancelar filtros -->
    <div>
        <button class="filter-btn" onclick="clearFilters()">Cancelar Filtros</button>
    </div>

    <!-- Lista de la Tier -->
    <div class="tier-list">
        <div class="tier" data-tier="S" ondrop="drop(event)" ondragover="allowDrop(event)">S
            <div class="characters" id="tier-S"></div>
        </div>
        <div class="tier" data-tier="A" ondrop="drop(event)" ondragover="allowDrop(event)">A
            <div class="characters" id="tier-A"></div>
        </div>
        <div class="tier" data-tier="B" ondrop="drop(event)" ondragover="allowDrop(event)">B
            <div class="characters" id="tier-B"></div>
        </div>
        <div class="tier" data-tier="C" ondrop="drop(event)" ondragover="allowDrop(event)">C
            <div class="characters" id="tier-C"></div>
        </div>
        <div class="tier" data-tier="D" ondrop="drop(event)" ondragover="allowDrop(event)">D
            <div class="characters" id="tier-D"></div>
        </div>
    </div>

    <script src="script.js"></script>

</body>
</html>
