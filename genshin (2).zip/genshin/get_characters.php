<?php

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "tier_list"; 

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Conexión fallida: " . $conn->connect_error);
}

$sql = "SELECT id, nombre, elemento, imagen_url, categoria, tipo_de_arma FROM personajes";
$result = $conn->query($sql);

$characters = array();

if ($result->num_rows > 0) {
   
    while($row = $result->fetch_assoc()) {
        $characters[] = $row;
    }
}


echo json_encode($characters);

$conn->close();
?>
