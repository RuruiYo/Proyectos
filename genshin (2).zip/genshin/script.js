const elementColors = {
    "Pyro": "red",
    "Hydro": "blue",
    "Electro": "purple",
    "Geo": "brown",
    "Anemo": "lightgreen",
    "Cryo": "cyan",
    "Dendro": "green"
};

let selectedElements = [];
let selectedWeapons = [];

async function loadCharacters() {
    const response = await fetch('get_characters.php');
    const characters = await response.json();

 
    document.querySelectorAll('.characters').forEach(tier => {
        tier.innerHTML = '';
    });

   
    for (const character of characters) {
        const div = document.createElement('div');
        div.className = 'character';
        div.style.backgroundImage = `url(${character.imagen_url})`;
        div.draggable = true;
        div.ondragstart = drag;
        div.dataset.id = character.id;
        div.dataset.element = character.elemento;
        div.style.borderColor = elementColors[character.elemento] || "white";
        div.id = `character-${character.id}`;

        const nameDiv = document.createElement('div');
        nameDiv.className = 'character-name';
        nameDiv.textContent = character.nombre;
        div.appendChild(nameDiv);

        document.getElementById(`tier-${character.categoria}`).appendChild(div);
    }
}

function toggleFilter(value, type) {
    let filterList = type === 'element' ? selectedElements : selectedWeapons;
    let filterName = type === 'element' ? 'Elementos' : 'Armas';

    if (filterList.includes(value)) {
        filterList = filterList.filter(item => item !== value);
    } else {
        filterList.push(value);
    }

  
    updateSelectedFilters();

    
    filterCharacters();
}

function updateSelectedFilters() {
    let activeFilters = '';
    if (selectedElements.length > 0) {
        activeFilters += 'Elementos: ' + selectedElements.join(', ') + ' ';
    }
    if (selectedWeapons.length > 0) {
        activeFilters += 'Armas: ' + selectedWeapons.join(', ');
    }
    document.getElementById('selected-filters').textContent = activeFilters || 'Ninguno';
}

async function filterCharacters() {
    const response = await fetch('get_characters.php');
    const characters = await response.json();

    const filteredCharacters = characters.filter(character => {
        let matchesElement = selectedElements.length === 0 || selectedElements.includes(character.elemento);
        let matchesWeapon = selectedWeapons.length === 0 || selectedWeapons.includes(character.tipo_de_arma);

        return matchesElement && matchesWeapon;
    });

  
    document.querySelectorAll('.characters').forEach(tier => {
        tier.innerHTML = '';
    });

 
    for (const character of filteredCharacters) {
        const div = document.createElement('div');
        div.className = 'character';
        div.style.backgroundImage = `url(${character.imagen_url})`;
        div.draggable = true;
        div.ondragstart = drag;
        div.dataset.id = character.id;
        div.dataset.element = character.elemento;
        div.style.borderColor = elementColors[character.elemento] || "white";
        div.id = `character-${character.id}`;

        const nameDiv = document.createElement('div');
        nameDiv.className = 'character-name';
        nameDiv.textContent = character.nombre;
        div.appendChild(nameDiv);

        document.getElementById(`tier-${character.categoria}`).appendChild(div);
    }
}

function clearFilters() {

    selectedElements = [];
    selectedWeapons = [];
    updateSelectedFilters();
    loadCharacters();
}

function allowDrop(event) {
    event.preventDefault();
}

function drag(event) {
    event.dataTransfer.setData("text", event.target.id);
}

function drop(event) {
    event.preventDefault();
    const data = event.dataTransfer.getData("text");
    const draggedElement = document.getElementById(data);

    if (event.target.classList.contains('characters')) {
        event.target.appendChild(draggedElement); 
        updateCharacterCategory(draggedElement.dataset.id, event.target.parentElement.dataset.tier);
    }
}

async function updateCharacterCategory(characterId, newCategory) {
    const formData = new FormData();
    formData.append('id', characterId);
    formData.append('categoria', newCategory);

    try {
        const response = await fetch('update_category.php', {
            method: 'POST',
            body: formData
        });

        const result = await response.text();
        if (result === 'success') {
            console.log('Categoría actualizada correctamente');
        } else {
            console.error('Error al actualizar la categoría');
        }
    } catch (error) {
        console.error('Error en la actualización de la categoría:', error);
    }
}



loadCharacters(); 

