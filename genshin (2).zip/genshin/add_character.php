<?php
$host = 'localhost';
$dbname = 'tier_list';
$username = 'root';
$password = '';

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    $stmt = $pdo->query("SELECT * FROM personajes");
    $characters = $stmt->fetchAll(PDO::FETCH_ASSOC);

    echo json_encode($characters);
} catch (PDOException $e) {
    die("Connection failed: " . $e->getMessage());
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Agregar Personaje</title>
</head>
<body>
    <form action="add_character.php" method="post">
        <label for="nombre">Nombre:</label>
        <input type="text" id="nombre" name="nombre" required>
        
        <label for="elemento">Elemento:</label>
        <select id="elemento" name="elemento" required>
            <option value="Pyro">Pyro</option>
            <option value="Hydro">Hydro</option>
            <option value="Electro">Electro</option>
            <option value="Geo">Geo</option>
            <option value="Anemo">Anemo</option>
            <option value="Cryo">Cryo</option>
            <option value="Dendro">Dendro</option>
        </select>
        
        <label for="imagen_url">URL de la imagen:</label>
        <input type="text" id="imagen_url" name="imagen_url" required>
        
        <label for="categoria">Categoría inicial:</label>
        <select id="categoria" name="categoria" required>
            <option value="S">S</option>
            <option value="A">A</option>
            <option value="B">B</option>
            <option value="C">C</option>
            <option value="D">D</option>
        </select>

        <label for="tipo_de_arma">Tipo de Arma:</label>
        <select id="tipo_de_arma" name="tipo_de_arma" required>
            <option value="Arco">Arco</option>
            <option value="Espada">Espada</option>
            <option value="Catalizador">Catalizador</option>
            <option value="Mandoble">Mandoble</option>
            <option value="Lanza">Lanza</option>
        </select>
        
        <button type="submit">Agregar Personaje</button>
    </form>
</body>
</html>

<?php
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nombre = $_POST['nombre'];
    $elemento = $_POST['elemento'];
    $imagen_url = $_POST['imagen_url'];
    $categoria = $_POST['categoria'];
    $tipo_de_arma = $_POST['tipo_de_arma'];
    

    $armas_permitidas = ['Arco', 'Espada', 'Catalizador', 'Mandoble', 'Lanza'];
    if (!in_array($tipo_de_arma, $armas_permitidas)) {
        die("Error: Tipo de arma no válido.");
    }
    
    try {
        $pdo = new PDO("mysql:host=$host;dbname=$dbname", $username, $password);
        $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

        $stmt = $pdo->prepare("INSERT INTO personajes (nombre, elemento, imagen_url, categoria, tipo_de_arma) VALUES (?, ?, ?, ?, ?)");
        $stmt->execute([$nombre, $elemento, $imagen_url, $categoria, $tipo_de_arma]);

        echo "Personaje agregado correctamente.";
    } catch (PDOException $e) {
        die("Connection failed: " . $e->getMessage());
    }
}
?>
